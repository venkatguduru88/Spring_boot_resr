package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.Employee;
import com.example.demo.dto.EmployeeDetails;

@RestController
public class ClientForEmployeeController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/employees")
	public ResponseEntity<EmployeeDetails> getEmployeeDetails(){
		EmployeeDetails details =restTemplate.getForObject("http://localhost:8088/employees", EmployeeDetails.class);
		return new ResponseEntity<EmployeeDetails>(details,HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable long id){
		Employee details =restTemplate.getForObject("http://localhost:8088/employees/"+id, Employee.class);
		return new ResponseEntity<>(details,HttpStatus.ACCEPTED);
		
	}
	
	@PostMapping("/employees")
	public ResponseEntity<Employee> saveEmployeeDetails(@RequestBody Employee employee){
		return restTemplate.postForEntity("http://localhost:8088/employees",employee, Employee.class);
		//return new ResponseEntity<>(details,HttpStatus.ACCEPTED);
		
	}
	
	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployeeDetails(@RequestBody Employee employee,@PathVariable long id){
		 restTemplate.put("http://localhost:8088/employees/"+id,employee, Employee.class);
		 Employee details =restTemplate.getForObject("http://localhost:8088/employees/"+id, Employee.class);
		return new ResponseEntity<>(details,HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> removeEmployeeDetails(@PathVariable long id){
		 restTemplate.delete("http://localhost:8088/employees/"+id);
		return new ResponseEntity<>("Deleted",HttpStatus.ACCEPTED);
		
	}
	

}
