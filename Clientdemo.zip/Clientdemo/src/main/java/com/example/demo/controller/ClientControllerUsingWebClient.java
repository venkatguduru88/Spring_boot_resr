package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.demo.dto.EmployeeDetails;

@RestController
@RequestMapping("/webclient")
public class ClientControllerUsingWebClient {
	
	@Autowired
	WebClient.Builder webClientBuilder;
	
	@GetMapping("/employees")
	public ResponseEntity<EmployeeDetails> getEmployeeDetails(){
	
		EmployeeDetails details =webClientBuilder.baseUrl("http://localhost:8088/employees").
				build().get().retrieve().bodyToMono(EmployeeDetails.class).block();
		return new ResponseEntity<EmployeeDetails>(details, HttpStatus.ACCEPTED);
	}
	
	

}
