package com.example.demo.dto;

import java.util.List;

public class EmployeeDetails {
	
	private List<Employee> employeeDetails;

	public List<Employee> getEmployeeDetails() {
		return employeeDetails;
	}

	public void setEmployeeDetails(List<Employee> employeeDetails) {
		this.employeeDetails = employeeDetails;
	}
	
	
	

}
