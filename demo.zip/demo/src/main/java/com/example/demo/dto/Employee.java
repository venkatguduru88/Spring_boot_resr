package com.example.demo.dto;

import java.io.Serializable;

public class Employee implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fname;
	private String lName;
	private String dob;
	private Long mobilrNum;
	private String address;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public Employee(String fname, String lName, String dob, Long mobilrNum, String address) {
		super();
		this.fname = fname;
		this.lName = lName;
		this.dob = dob;
		this.mobilrNum = mobilrNum;
		this.address = address;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public Long getMobilrNum() {
		return mobilrNum;
	}
	public void setMobilrNum(Long mobilrNum) {
		this.mobilrNum = mobilrNum;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	

}
