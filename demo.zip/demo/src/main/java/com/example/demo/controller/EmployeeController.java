package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Employee;

@RestController
public class EmployeeController {
	
	@GetMapping("/employee")
	public Employee getEmloyee(@PathVariable("name")String name){
		System.out.println("from get Employee"+name);
		return new Employee("venkat","guduru","15-08-197",996832446L,"Reddy Gudem");
		
	}

}
