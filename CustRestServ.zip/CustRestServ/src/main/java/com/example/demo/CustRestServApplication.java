package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustRestServApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustRestServApplication.class, args);
	}

}
