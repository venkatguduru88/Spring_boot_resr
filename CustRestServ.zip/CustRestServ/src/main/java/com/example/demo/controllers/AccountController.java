package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.AccountDao;
import com.example.demo.dto.Accounts;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	@Autowired
	AccountDao accountDao;
	
	@GetMapping("/accounts")
	public ResponseEntity<?> getAllAccounts(){
		List<Accounts> list= accountDao.findAll();
		ResponseEntity<?> response;
		if(list == null) {
			response=new ResponseEntity<String>("No data found..", HttpStatus.OK);
		}
		response=new ResponseEntity<List<Accounts>>(list, HttpStatus.OK);
		
		return response;
	}

}
